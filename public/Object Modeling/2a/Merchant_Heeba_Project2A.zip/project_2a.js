// Sample code for Project 2A
// Draws 3D Simple Shapes (box, cylinder, sphere, cone, torus)


let time = 0;  // track time passing, used to move the objects

function setup() {
  createCanvas(800, 800, WEBGL);
  
  let fov = 60.0;  // 60 degrees FOV
  perspective(PI * fov / 180.0, width / height, 0.1, 2000);
}

// called repeatedly to draw new per-frame images
function draw() {
  
  background(255, 255, 255);  //  white background

  
  // set the virtual camera position
  // camera(0, 0, 85, 0, 0, 0, 0, 1, 0);  // from, at, up
  camera(0, -100, 200, 0, 0, 0, 0, 1, 0);
  // orbitControl();
  
  // include some light even in shadows
  ambientLight(200, 175, 175);
  
  // set light position
  pointLight(255, 255, 255, 100, -150, 500);
  pointLight(255, 255, 255, -100, -250, -500); // position: left below back
  emissiveMaterial(15);
  specularMaterial(50);
  shininess(75);

  noStroke();  // don't draw polygon outlines
  
  let delta = 25;

  // use sine waves to move simmple shapes

// record player - trial
const s = 45;
const h = 7;

// main base
fill(200,95,85);
push();
translate(0, 0);
let box_axis = createVector (0.0, 1.0, 0.0);
rotate (-time, box_axis);


// Right Edge
push();
translate(s/2, 0, 0);
rotateX(PI/2);
scale(.125, 1, 1);
cylinder(h/2, s);
pop();

// Left Edge
push();
translate(-s/2, 0, 0);
rotateX(PI/2);
scale(.125, 1, 1);
cylinder(h/2, s);
pop();

// Near Edge
push();
translate(0, 0, s/2);
rotateX(PI/2);
rotateZ(PI/2);
scale(.125, 1, 1);
cylinder(h/2, s);
pop();

// Near Edge
push();
translate(0, 0, -s/2);
rotateX(PI/2);
rotateZ(PI/2);
scale(.125, 1, 1);
cylinder(h/2, s);
pop();


// round corners
// front right
push();
translate(s/2, 0, s/2);
rotateX(PI/2);
scale(0.12, 0.145, 1);
sphere(h/2);
pop();

// front left
push();
translate(-s/2, 0, s/2);
rotateX(PI/2);
scale(0.12, 0.145, 1);
sphere(h/2);
pop();

// back right
push();
translate(s/2, 0, -s/2);
rotateX(PI/2);
scale(0.12, 0.145, 1);
sphere(h/2);
pop();

// back left
push();
translate(-s/2, 0, -s/2);
rotateX(PI/2);
scale(0.12, 0.145, 1);
sphere(h/2);
pop();

// bottom edges
push()
translate(0, 3, 0);
box(s+2, 2, s+2);

// legs
fill(51, 51, 51);

// back right corner
push();
translate(19, 0, 19);
rotateY(PI/2);
cylinder(3, 7, 50);
pop();

// front right corner
push();
translate(-19, 0, 19);
rotateY(PI/2);
cylinder(3, h, 50);
pop();

// back left corner
push();
translate(-19, 0, -19);
rotateY(PI/2);
cylinder(3, h, 50);
pop();

// front left corner
push();
translate(19, 0, -19);
rotateY(PI/2);
cylinder(3, h, 50);
pop();

pop();

// top box close
push();
translate(0, -h/2, 0);
box(s, 0.1, s);
pop();


// top
translate(0, -3.5, 0);
box(43, 0.5, 43);

// Details: white cirlces
fill(239, 236, 227);
push();
translate(18.5, 0, 18.5);
cylinder(2, 2, 50);
pop();

push();
translate(-18.5, 0, 18.5);
cylinder(2, 2, 50);
pop();

// CD stack
// total - 4
// 1
fill(93, 93, 93);
push();
translate(0, -0.5, 0);
cylinder(16, 0.4, 50);
pop();

// layer 1
fill(239, 236, 227);
push();
translate(0, -0.8, 0);
cylinder(16, 0.1, 50);
pop();

// 2
fill(93, 93, 93);
push();
translate(0, -1.1, 0);
cylinder(15.5, 0.4, 50);
pop();

// layer 2
fill(239, 236, 227);
push();
translate(0, -1.3, 0);
cylinder(15.5, 0.1, 50);
pop();

// layer 3
fill(93, 93, 93);
push();
translate(0, -1.4, 0);
cylinder(15, 0.1, 50);
pop();

// main layer
fill(239, 236, 227);
push();
translate(0, -1.6, 0);
cylinder(13, 0.7, 50);
pop();


// middle space
// Outer rim
fill(200, 95, 85);  // Match base color
push();
translate(0, -1.8, 0);
cylinder(5, 0.5, 50);
pop();

// Inner recessed area
fill(255, 160, 150); 
push();
translate(0, -1.7, 0);
cylinder(5, 0.3, 50);
pop();

// center spindle
fill(51, 51, 51);
push();
translate(0, -3, 0);
cylinder(0.9, 2, 50);
pop();

// spin button
// bottom
fill(51, 51, 51);
push();
translate(-16, -0.2, -16);
cylinder(0.7, 0.6, 50);
pop();

// top
fill(51, 51, 51);
push();
translate(-16, -1.5, -16);
cylinder(0.9, 2, 50);
pop();

// spin button 2
// bottom
fill(239, 236, 227);
push();
translate(-7, -0.2, -19);
cylinder(0.7, 4, 50);
pop();

// top
fill(239, 236, 227);
push();
translate(-7, -3, -19);
cylinder(0.9, 1.5, 50);
pop();

// mover 
// bottom
fill(51, 51, 51);
push();
translate(17, -0.5, -17);
cylinder(4, 0.8, 50);
pop();

// layer
fill(51, 51, 51);
push();
translate(17, -1, -17);
cylinder(3.5, 0.3, 50);
pop();

// top
fill(51, 51, 51);
push();
translate(17, -1, -17);
scale(1, 0.5, 1);
sphere(2);
pop();

fill(51, 51, 51);
push();
translate(17, -1, -17);
cylinder(1.3, -6, 50);
pop();

fill(239, 236, 227);
push();
translate(17, -6, -17);
rotateX(PI/2);
rotateZ(PI/4);
cylinder(2, -6, 50);
pop();

push();
translate(19, -6, -19);
rotateX(PI/2);
rotateZ(PI/4);
sphere(2);
pop();

fill(51, 51, 51);
push();
translate(11, -6, -11);
rotateX(PI/2);
rotateZ(PI/4);
cylinder(0.8, 15, 50);
pop();

fill(51, 51, 51);
push();
translate(5, -6, -5);
rotateX(-PI/2);
rotateZ(PI/4);
box(3, 2, 3)
pop();

fill(16, 16, 16);
push();
translate(5, -4, -5);
cone(1, 4, 50);
pop();

  time += 0.01;  // update the time
}

function keyPressed() {
  if (key === 's' || key === 'S') {
    saveCanvas('your_object.jpg');
  }
}
